from flaskr import app
from flask import Flask
import os
from flask import current_app, g, render_template, redirect, request, session, url_for, flash
from flask.cli import with_appcontext
import fdb
import flaskr.db


@app.route('/home', methods =["POST", "GET"])
def home():
    if g.user is  None:
        return redirect(url_for('login'))
    else:
        conn = flaskr.db.get_db()
        buttons = '0'
        if request.method == 'POST':
            if 'edit' in request.form:
                buttons = '1'
            if 'save' in request.form:
                buttons = '0'
                name = request.form['name']
                surname = request.form['surname']
                patronomic = request.form['patronomic']
                number_phone = request.form['phone']
                marka = request.form['mark']
                model = request.form['model']
                number_auto = request.form['number_auto']
                conn.cursor().execute('UPDATE CLIENTS SET NAME = ?, SURNAME = ?, PATRONOMIC = ?,'
                                      'NUMBER_PHONE = ?, MARK_AUTO = ?, MODEL_AUTO = ?,'
                                      'NUMBER_AUTO = ? WHERE ID_USERS = ?', (name, surname, patronomic,
                                                                             number_phone, marka, model,
                                                                             number_auto, g.user,))
                conn.commit()
        data_clients_profile = conn.cursor().execute('SELECT * FROM CLIENTS WHERE ID_USERS= ?',
                                                     (g.user,)).fetchall()
        conn = flaskr.db.close_db()
        return render_template('home_client.html', data=data_clients_profile, buttons = buttons)