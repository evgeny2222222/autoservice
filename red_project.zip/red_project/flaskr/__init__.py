from flask import Flask
import os
from flask import current_app, g, render_template, redirect, request, session, url_for, flash
from flask.cli import with_appcontext
import fdb
import flaskr.db
from datetime import datetime
import copy
from decimal import *
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, instance_relative_config=True)
app.config.from_mapping(
    SECRET_KEY = 'username',
    DATABASE = os.path.join(app.instance_path, '/var/rdb/bdflask'),
    USER = 'sysdba',
    PASSWORD = 'masterkey',
    LIBRARY = os.path.join(app.root_path, 'rdb/libfbclient.so.3.0.6')
)

@app.before_request
def before_request():
    user_id = session.get('user_id')
    role = session.get('role')
    if user_id is None:
        g.user = None
    else:
        g.user = user_id
        g.role = role

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods =["POST", "GET"])
def login():
    if request.method == "POST":
        user = request.form['username']
        password = request.form['password']
        conn = flaskr.db.get_db()
        error = None
        if conn is None:
            error = 'Подключение к базе данных не найдено'
        users = conn.cursor().execute('SELECT * FROM USERS').fetchall()
        if users is None:
            error = 'Записи в бд не найдены'
        else:
            for x in users:
                if x[2] == user and check_password_hash(x[1],password):
                    if x[0]==1:
                        session.clear()
                        session['user_id']=x[0]
                        session['role']= 'admin'
                        print('Админ', session)
                        return redirect(url_for('services'))
                    clients = conn.cursor().execute('SELECT * FROM CLIENTS').fetchall()
                    for i in clients:
                        if i[1] == x[0]:
                            session.clear()
                            session['user_id'] = x[0]
                            session['role'] = 'client'
                            print('Клиент', session)
                            return redirect(url_for('home'))
                    masters = conn.cursor().execute('SELECT * FROM MASTER WHERE DATE_DISMISSAL IS  NULL').fetchall()
                    for i in masters:
                        if i[1] == x[0]:
                            session.clear()
                            session['user_id'] = x[0]
                            session['role'] = 'master'
                            return redirect(url_for('accept_request'))
                elif x[2] == user and x[1] != password:
                    error = 'Не верный пароль'
                elif x[2] != user:
                    error = 'Пользователь не найден'
        conn = flaskr.db.close_db()
        flash(error)
    return render_template('login.html')


@app.route('/register', methods =["POST", "GET"])
def register():
    if request.method == "POST":
        client_reg = { 'name': request.form['name'], 'login': request.form['login'],
                      'password': request.form['password']}
        error = None
        for key in client_reg:
            if client_reg[key]=='':
                error = "Поле " + key + " не заполнено"
                flash(error)

        if error is None:
            conn = flaskr.db.get_db()
            if conn is None:
                error = 'Подключение к базе данных не найдено'
                flash(error)
            else:
                copies = conn.cursor().execute('SELECT ID_USERS, LOGIN FROM USERS WHERE LOGIN = ?',
                                               (client_reg['login'],)).fetchall()
                for i in copies:
                    if i[1]==client_reg['login']:
                        error = f'Пользователь  уже зарегистрирован'
                        flash(error)
                if error is None:
                    conn.cursor().execute(
                        "INSERT INTO USERS (LOGIN, PASSWORD) VALUES (?, ?)",
                        (client_reg['login'], generate_password_hash(client_reg['password']))
                    )
                    data = conn.cursor().execute('SELECT * FROM USERS WHERE LOGIN = ?',
                                                 (client_reg['login'],)).fetchall()
                    print(data[0][0])
                    conn.cursor().execute(
                        "INSERT INTO CLIENTS (ID_USERS,NAME) VALUES (?, ?)",
                        (data[0][0], client_reg['name'])
                    )
                    conn.commit()
                    return redirect(url_for("login"))

        #шифрование пароля
        conn = flaskr.db.close_db()
    return render_template('reg.html')

@app.route('/home', methods =["POST", "GET"])
def home():
    if g.user is not None and g.role == 'client':
        conn = flaskr.db.get_db()
        buttons = '0'
        if request.method == 'POST':
            if 'edit' in request.form:
                buttons = '1'
            if 'save' in request.form:
                buttons = '0'
                name = request.form['name']
                surname = request.form['surname']
                patronomic = request.form['patronomic']
                number_phone = request.form['phone']
                marka = request.form['mark']
                model = request.form['model']
                number_auto = request.form['number_auto']
                conn.cursor().execute('UPDATE CLIENTS SET NAME = ?, SURNAME = ?, PATRONOMIC = ?,'
                                      'NUMBER_PHONE = ?, MARK_AUTO = ?, MODEL_AUTO = ?,'
                                      'NUMBER_AUTO = ? WHERE ID_USERS = ?', (name, surname, patronomic,
                                                                             number_phone, marka, model,
                                                                             number_auto, g.user,))
                conn.commit()
        data_clients_profile = conn.cursor().execute('SELECT * FROM CLIENTS WHERE ID_USERS= ?',
                                                     (g.user,)).fetchall()
        conn = flaskr.db.close_db()
    else:
        return redirect(url_for('login'))
    return render_template('home_client.html', data=data_clients_profile, buttons = buttons)

@app.route('/exit', methods =["POST", "GET"])
def exit():
    session.clear()
    return redirect(url_for('login'))

@app.route('/sign', methods =["POST", "GET"])
def sign():
    if g.user is not None and g.role == 'client':
        current_date = datetime.now().date()
        conn = flaskr.db.get_db()
        type_services = conn.cursor().execute('SELECT * FROM TYPE_OF_SERVICE WHERE ACTIVE = True').fetchall()
        time = ['09:00:00', '10:00:00', '11:00:00', '12:00:00','13:00:00', '14:00:00',
                '15:00:00','16:00:00','17:00:00']
        new_time = copy.copy(time)
        button = '0'
        select_date = datetime.now().date()
        if request.method == 'POST':
            try:
                if 'day' in request.form:
                    button = '1'
                    date = request.form['date']
                    select_date = date
                    requests = conn.cursor().execute('SELECT * FROM REQUEST_REPAIR '
                                                     'WHERE CAST(DATA_TIME AS DATE) = ? '
                                                     'AND STATUS <> ?', (date, 'Отменена')).fetchall()
                    for i in range(len(requests)):
                        for j in range(len(time)):
                            if time[j] == str(datetime.time(requests[i][5])):
                                new_time.remove(time[j])

                if 'send' in request.form:
                    date = request.form['date']
                    time = request.form['time']
                    type_of_services = request.form['select']
                    id_client = conn.cursor().execute('SELECT ID_CLIENT FROM CLIENTS WHERE ID_USERS = ?',
                                                      (g.user,)).fetchall()
                    conn.cursor().execute(
                        "INSERT INTO REQUEST_REPAIR (ID_CLIENT,ID_TYPE_OF_SERVICES,STATUS,DATA_TIME) VALUES (?, ?,?,?)",
                        (id_client[0][0], type_of_services, 'Новая', date + ' ' + time)
                    )
                    conn.commit()
            except KeyError:
                flash('Не выбрано значение')
        conn = flaskr.db.close_db()
    else:
        return redirect(url_for('login'))
    return render_template('sign.html',type_services=type_services, current_date=current_date, new_time=new_time, button=button, select_date=select_date)

@app.route('/req', methods =["POST", "GET"])
def req():
    if g.user is not None and g.role == 'client':
        conn = flaskr.db.get_db()
        id_client = conn.cursor().execute('SELECT ID_CLIENT FROM CLIENTS '
                                         'WHERE ID_USERS = ?', (g.user,)).fetchall()

        requests = conn.cursor().execute('SELECT ID_REQUEST,TYPE_OF_SERVICE.NAME, MASTER.NAME, '
                                         'MASTER.NUMBER_PHONE,DATA_TIME,STATUS FROM REQUEST_REPAIR '
                                         'JOIN TYPE_OF_SERVICE ON ID_TYPE=ID_TYPE_OF_SERVICES '
                                         'LEFT OUTER JOIN MASTER USING(ID_MASTER) '
                                         'WHERE  STATUS <> ? AND ID_CLIENT = ? '
                                         'ORDER BY DATA_TIME ASC', ('Выполнена',id_client[0][0],)).fetchall()
        if request.method == 'POST':
            try:
                reset_value = request.form['select']
                conn.cursor().execute('UPDATE REQUEST_REPAIR SET STATUS = ? '
                                      'WHERE ID_REQUEST = ?', ('Отменена',reset_value))
                conn.commit()
                return redirect(url_for('req'))
                conn = flaskr.db.close_db()
            except KeyError:
                flash('Не выбрано значение')
    else:
        return redirect(url_for('login'))
    return render_template('my_request.html', requests=requests)

@app.route('/my_visits')
def my_visits():
    if g.user is not None and g.role == 'client':
        conn = flaskr.db.get_db()
        id_client = conn.cursor().execute('SELECT ID_CLIENT FROM CLIENTS '
                                          'WHERE ID_USERS = ?', (g.user,)).fetchall()
        remonts = conn.cursor().execute('SELECT ID_REQUEST, TYPE_OF_SERVICE.NAME, DETAIL.NAME_DETAIL, '
                                        'DATA_TIME, MASTER.NAME, MASTER.NUMBER_PHONE, '
                                        'SUMMA_REMONT, FINAL_SUMMA FROM REMONT'
                                        ' JOIN REQUEST_REPAIR USING(ID_REQUEST) '
                                        'JOIN DETAIL ON ID_DETAIL=ID_DETAL '
                                        'JOIN TYPE_OF_SERVICE ON TYPE_OF_SERVICE.ID_TYPE=REQUEST_REPAIR.ID_TYPE_OF_SERVICES'
                                        ' JOIN MASTER USING(ID_MASTER)'
                                        'WHERE ID_CLIENT = ? AND REQUEST_REPAIR.STATUS= ?',(id_client[0][0],'Выполнена',)).fetchall()
    else:
        return redirect(url_for('login'))
    return render_template('my_visits.html', remonts=remonts)

@app.route('/accept_request', methods=["POST", "GET"])
def accept_request():
    if g.user is not None and g.role == 'master':
        conn = flaskr.db.get_db()
        requests = conn.cursor().execute('SELECT ID_REQUEST,TYPE_OF_SERVICE.NAME,DATA_TIME, CLIENTS.NAME,'
                                         'CLIENTS.SURNAME,  CLIENTS.PATRONOMIC,  CLIENTS.NUMBER_PHONE,'
                                         'CLIENTS.MARK_AUTO, CLIENTS.MODEL_AUTO, CLIENTS.NUMBER_AUTO'
                                         ' FROM REQUEST_REPAIR'
                                         ' JOIN TYPE_OF_SERVICE ON TYPE_OF_SERVICE.ID_TYPE=REQUEST_REPAIR.ID_TYPE_OF_SERVICES'
                                         ' JOIN CLIENTS USING(ID_CLIENT)'
                                         ' WHERE STATUS=?', ('Новая',)).fetchall()
        if request.method == 'POST':
            try:
                select_request = request.form['select']
                master = conn.cursor().execute('SELECT ID_MASTER FROM MASTER'
                                               ' WHERE ID_USER = ?', (g.user,)).fetchall()
                if 'accept' in request.form:
                    conn.cursor().execute('UPDATE REQUEST_REPAIR SET ID_MASTER = ?, STATUS = ?'
                                          ' WHERE ID_REQUEST = ?', (master[0][0], 'Принята', select_request))
                    conn.commit()
                if 'reset' in request.form:
                    conn.cursor().execute('UPDATE REQUEST_REPAIR SET ID_MASTER = ?, STATUS = ?'
                                          ' WHERE ID_REQUEST = ?', (master[0][0], 'Отклонена', select_request))
                    conn.commit()
                return redirect(url_for('accept_request'))
            except KeyError:
                flash('Не выбрано значение')
        conn = flaskr.db.close_db()
    else:
        return redirect(url_for('login'))
    return render_template('request_on_service.html', requests=requests)

@app.route('/detail_order', methods=["POST", "GET"])
def detail_order():
    if g.user is not None and g.role == 'master':
        conn = flaskr.db.get_db()
        detail = conn.cursor().execute('SELECT * FROM DETAIL').fetchall()
        if request.method == 'POST' and g.role=='master':
            name = request.form['name']
            manufacture = request.form['manufacter']
            dop_info = request.form['dop']
            conn.cursor().execute(
                "INSERT INTO DETAIL (NAME_DETAIL,MANIFACTURER, ADD_INFO,STATUS) VALUES (?, ?,?,?)",
                (name, manufacture, dop_info, 'Заказано')
            )
            conn.commit()
        conn = flaskr.db.close_db()
    else:
        return redirect(url_for('login'))
    return render_template('detail_order.html', detail=detail)

@app.route('/remont', methods=["POST", "GET"])
def remont():
    if g.user is not None and g.role == 'master':
        conn = flaskr.db.get_db()
        master = conn.cursor().execute('SELECT ID_MASTER FROM MASTER WHERE ID_USER = ?', (g.user,)).fetchall()
        requests = conn.cursor().execute('SELECT ID_REQUEST,TYPE_OF_SERVICE.NAME,DATA_TIME, CLIENTS.NAME,'
                                         'CLIENTS.SURNAME,  CLIENTS.PATRONOMIC,  CLIENTS.NUMBER_PHONE,'
                                         'CLIENTS.MARK_AUTO, CLIENTS.MODEL_AUTO, CLIENTS.NUMBER_AUTO'
                                         ' FROM REQUEST_REPAIR'
                                         ' JOIN TYPE_OF_SERVICE ON TYPE_OF_SERVICE.ID_TYPE=REQUEST_REPAIR.ID_TYPE_OF_SERVICES'
                                         ' JOIN CLIENTS USING(ID_CLIENT)'
                                         ' WHERE STATUS=? AND ID_MASTER = ?', ('Принята',master[0][0],)).fetchall()
        detail = conn.cursor().execute('SELECT ID_DETAIL , NAME_DETAIL, MANIFACTURER'
                                       ' FROM DETAIL WHERE STATUS = ?', ('На складе',)).fetchall()
        if request.method == 'POST':
            try:
                if 'save' in request.form:
                    select_request = request.form['select']
                    select_detail = request.form['detail']
                    if select_detail=='Выберите деталь':
                        return redirect(url_for('remont'))
                    value_type_of_service = conn.cursor().execute('SELECT TYPE_OF_SERVICE.SALARY FROM REQUEST_REPAIR'
                                                                  ' JOIN TYPE_OF_SERVICE ON TYPE_OF_SERVICE.ID_TYPE='
                                                                  'REQUEST_REPAIR.ID_TYPE_OF_SERVICES'
                                                                  ' WHERE ID_REQUEST = ?', (select_request,)).fetchall()
                    value_detail = conn.cursor().execute('SELECT SALARY '
                                                         'FROM DETAIL WHERE ID_DETAIL = ?', (select_detail,)).fetchall()
                    conn.cursor().execute(
                        "INSERT INTO REMONT (ID_DETAL,SUMMA_REMONT,FINAL_SUMMA,ID_REQUEST) VALUES (?, ?,?,?)",
                        (select_detail, value_type_of_service[0][0], value_type_of_service[0][0] +
                         value_detail[0][0], select_request)
                    )
                    conn.cursor().execute('UPDATE REQUEST_REPAIR SET STATUS = ?'
                                          ' WHERE ID_REQUEST = ?', ('Выполнена', select_request,))
                    conn.cursor().execute('UPDATE DETAIL SET STATUS = ?'
                                          ' WHERE ID_DETAIL = ?', ('Отсутствует', select_detail,))
                    conn.commit()
                    return redirect(url_for('remont'))
            except KeyError:
                flash('Не выбрано значение')
        conn = flaskr.db.close_db()
    else:
        return redirect(url_for('login'))
    return render_template('remont.html', requests=requests, detail=detail)

@app.route('/finish_remont', methods=["POST", "GET"])
def finish_remont():
    if g.user is not None and g.role == 'master':
        conn = flaskr.db.get_db()
        master = conn.cursor().execute('SELECT ID_MASTER FROM MASTER WHERE ID_USER = ?', (g.user,)).fetchall()
        remont = conn.cursor().execute('SELECT ID_REQUEST,TYPE_OF_SERVICE.NAME,DATA_TIME,CLIENTS.NAME,'
                                       'SURNAME,PATRONOMIC,NUMBER_PHONE,MARK_AUTO,MODEL_AUTO,NUMBER_AUTO,'
                                       'SUMMA_REMONT FROM REMONT JOIN REQUEST_REPAIR USING(ID_REQUEST) '
                                       'JOIN TYPE_OF_SERVICE ON  TYPE_OF_SERVICE.ID_TYPE=REQUEST_REPAIR.ID_TYPE_OF_SERVICES '
                                       'JOIN CLIENTS USING(ID_CLIENT) WHERE ID_MASTER=? AND STATUS=?', (master[0][0],'Выполнена',)).fetchall()
        conn = flaskr.db.close_db()
    else:
        return redirect(url_for('login'))
    return render_template('finish_remont.html', remont=remont)

@app.route('/services', methods=["POST", "GET"])
def services():
    if g.user is not None and g.role == 'admin':
        conn = flaskr.db.get_db()
        type_of_services = conn.cursor().execute('SELECT * FROM TYPE_OF_SERVICE WHERE ACTIVE = True').fetchall()
        if request.method == 'POST':
            try:
                if 'delete' in request.form:
                    id_type_of_services = request.form['select']
                    conn.cursor().execute('UPDATE TYPE_OF_SERVICE SET ACTIVE = ?'
                                          ' WHERE ID_TYPE = ?', ('false',id_type_of_services,))
                if 'save' in request.form:
                    name = request.form['name']
                    salary = request.form['salary']
                    conn.cursor().execute(
                        "INSERT INTO TYPE_OF_SERVICE (NAME,SALARY) VALUES (?, ?)",
                        (name, salary))
                conn.commit()
                return redirect(url_for('services'))
            except KeyError:
                flash('Не выбрано значение')
        conn = flaskr.db.close_db()
    else:
        return redirect(url_for('login'))
    return render_template('services.html', type_of_services=type_of_services)

@app.route('/detailon', methods=["POST", "GET"])
def detailon():
    if g.user is not None and g.role == 'admin':
        conn = flaskr.db.get_db()
        detail = conn.cursor().execute('SELECT * FROM DETAIL WHERE STATUS != ?', ('Отсутствует',)).fetchall()
        if request.method == 'POST':
            try:
                detail_on = request.form['select_detail']
                detail_salary = request.form[detail_on]
                if detail_salary=='None':
                    detail_salary=0
                conn.cursor().execute('UPDATE DETAIL SET SALARY = ?, STATUS = ?'
                                      ' WHERE ID_DETAIL = ?', (detail_salary,'На складе',detail_on,))
                conn.commit()
                return redirect(url_for('detailon'))
            except KeyError:
                flash('Не выбрано значение')
        conn = flaskr.db.close_db()
    else:
        return redirect(url_for('login'))
    return render_template('detail_on_sklad.html',detail=detail)

@app.route('/staff', methods=["POST", "GET"])
def staff():
    if g.user is not None and g.role == 'admin':
        conn = flaskr.db.get_db()
        masters = conn.cursor().execute('SELECT * FROM MASTER').fetchall()
        if request.method == 'POST':
            return redirect(url_for('new_master'))
        conn = flaskr.db.close_db()
    else:
        return redirect(url_for('login'))
    return render_template('staff.html', masters=masters)

@app.route('/master/<path:id>', methods=["POST","GET"])
def master(id):
    buttons = '0'
    conn = flaskr.db.get_db()
    master = conn.cursor().execute('SELECT * FROM MASTER '
                                   'JOIN USERS ON MASTER.ID_USER=USERS.ID_USERS '
                                   'WHERE ID_MASTER = ?', (id,)).fetchall()
    if request.method == 'POST':
        if 'edit' in request.form:
            buttons = '1'
        if 'save' in request.form:
            buttons = '0'
            name = request.form['name']
            double_name = request.form['fio']
            patronomic = request.form['patronomic']
            qualification = request.form['qualification']
            number_phone = request.form['number_phone']
            login = request.form['login']
            password = request.form['password']
            conn.cursor().execute('UPDATE MASTER SET QUALIFICATION = ?, NUMBER_PHONE = ?, '
                                  ' NAME = ?, SURNAME = ?, PATRONOMIC = ?'
                                  ' WHERE ID_MASTER = ?', (qualification, number_phone, name,
                                                           double_name,patronomic, id,))
            conn.cursor().execute('UPDATE USERS SET LOGIN = ?, PASSWORD = ?'
                                  ' WHERE ID_USERS = ?', (login, password, g.user,))
            conn.commit()
        if 'delete' in request.form:
            buttons = '2'
        if 'yes' in request.form:
            current_date = datetime.now().date()
            conn.cursor().execute('UPDATE MASTER SET DATE_DISMISSAL = ? WHERE ID_MASTER = ?', (current_date,id,))
            conn.commit()
            return redirect(url_for('staff'))
        conn.close()
    return render_template('master.html', master=master, buttons=buttons)

@app.route('/new_master', methods=["POST","GET"])
def new_master():
    conn = flaskr.db.get_db()
    if request.method == 'POST':
        current_date = datetime.now().date()
        name = request.form['name']
        double_name = request.form['fio']
        patronomic = request.form['patronomic']
        qualification = request.form['qualification']
        number_phone = request.form['number_phone']
        login = request.form['login']
        password = generate_password_hash(request.form['password'])
        conn.cursor().execute(
            "INSERT INTO USERS (LOGIN,PASSWORD) VALUES (?, ?)",
            (login, password))
        conn.commit()
        id_user = conn.cursor().execute('SELECT ID_USERS FROM USERS '
                                       'WHERE LOGIN = ? and PASSWORD = ?', (login,password)).fetchall()
        conn.cursor().execute(
            "INSERT INTO MASTER (QUALIFICATION,DATE_RECEPTION,NUMBER_PHONE,"
            "NAME,SURNAME,PATRONOMIC,ID_USER) VALUES (?, ?,?,?,?,?,?)",
            (qualification,current_date,number_phone,name,double_name,patronomic,id_user[0][0]))
        conn.commit()
    conn.close()
    return render_template('new_master.html')

@app.route('/profit', methods=["POST","GET"])
def profit():
    conn = flaskr.db.get_db()
    month = ['Январь', 'Февраль','Март','Апрель','Май','Июнь','Июль','Август',
             'Сентябрь','Октябрь','Ноябрь','Декабрь']
    if request.method == 'POST':
        mon = request.form['time']
        number_month = month.index(mon)

        remonts = conn.cursor().execute('SELECT ID_REQUEST,TYPE_OF_SERVICE.NAME,CLIENTS.MARK_AUTO, '
                                        'CLIENTS.MODEL_AUTO,DATA_TIME, CLIENTS.NAME,CLIENTS.SURNAME,'
                                        ' CLIENTS.PATRONOMIC, MASTER.NAME, MASTER.SURNAME, MASTER.PATRONOMIC,'
                                        'DETAIL.SALARY, SUMMA_REMONT, FINAL_SUMMA FROM REMONT '
                                        'JOIN REQUEST_REPAIR USING(ID_REQUEST) '
                                        'JOIN TYPE_OF_SERVICE ON TYPE_OF_SERVICE.ID_TYPE=REQUEST_REPAIR.ID_TYPE_OF_SERVICES'
                                        ' JOIN CLIENTS USING(ID_CLIENT) JOIN MASTER USING(ID_MASTER) '
                                        'JOIN DETAIL ON DETAIL.ID_DETAIL=REMONT.ID_DETAL'
                                        ' WHERE EXTRACT(MONTH FROM DATA_TIME) = ?', (number_month+1,)).fetchall()
        show = conn.cursor().execute('SELECT  COUNT(ID_REMONT), SUM(SALARY), SUM(SUMMA_REMONT) FROM REMONT'
                                     ' JOIN DETAIL ON DETAIL.ID_DETAIL=REMONT.ID_DETAL'
                                     ' JOIN REQUEST_REPAIR USING(ID_REQUEST)'
                                     ' WHERE EXTRACT(MONTH FROM DATA_TIME) = ?', (number_month+1,)).fetchall()
        salary_master = conn.cursor().execute('SELECT SUM(SALARY) FROM CALCULATE_SALARY '
                                              'WHERE EXTRACT(MONTH FROM MON) = ?',(number_month+1,)).fetchall()
        profit = show[0][1] + show[0][2] - salary_master[0][0]
        return render_template('profit.html', month=month, remonts=remonts, show=show, salary_master=salary_master,
                               profit=profit)
    conn.close()
    return render_template('profit.html', month=month)

@app.route('/calculate_salary', methods=["POST","GET"])
def calculate_salary():
    conn = flaskr.db.get_db()
    month = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август',
             'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь']
    sal = conn.cursor().execute('SELECT * FROM CALCULATE_SALARY '
                                ' JOIN MASTER USING(ID_MASTER) WHERE DATE_DISMISSAL IS NULL').fetchall()
    if request.method == 'POST':
        mon = request.form['time']
        number_month = month.index(mon)
        id_all_masters = conn.cursor().execute('SELECT ID_MASTER FROM MASTER WHERE DATE_DISMISSAL IS NULL').fetchall()
        length = len(id_all_masters)
        for i in range(length):
            value_executed_works = conn.cursor().execute('SELECT COUNT(ID_REMONT), SUM(SUMMA_REMONT) FROM REMONT'
                                                         ' JOIN REQUEST_REPAIR USING(ID_REQUEST)'
                                                         ' WHERE EXTRACT(MONTH FROM DATA_TIME) = ?'
                                                         ' and REQUEST_REPAIR.ID_MASTER = ?',
                                                         (number_month + 1, id_all_masters[i][0],)).fetchall()
            value_works = 0
            if value_executed_works[0][1] != None:
                value_works = Decimal(value_executed_works[0][1]) * Decimal('0.5')

            active = False
            for j in sal:
                if j[0]==id_all_masters[i][0]:
                    active= True
            if active == True:
                conn.cursor().execute('UPDATE CALCULATE_SALARY SET EXECUTED_WORKS = ?, '
                                      'SALARY = ? WHERE ID_MASTER = ?', (
                                          value_executed_works[0][0],
                                          value_works, id_all_masters[i][0],))
                conn.commit()
            else:
                conn.cursor().execute('INSERT INTO CALCULATE_SALARY '
                                      '(ID_MASTER,EXECUTED_WORKS,MON,SALARY) '
                                      'VALUES (?,?,?,?)', (
                                      id_all_masters[i][0], value_executed_works[0][0], '2021-12-23 10:00:00',
                                      value_works))
            conn.commit()
    conn.close()
    return render_template('calculate_salary.html', month=month, sal=sal)

if __name__ == "__main__":
    app.run(debug=True)

